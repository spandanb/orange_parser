from django.http import HttpResponse
from django.shortcuts import render
from models import server as VMs
from models import chain as Chains
from models import FlowEntry
from Drivers.NeutronDriver import NeutronClient
from Drivers.JanusDriver import JanusClient
from controllers.ChainController import ChainController
import httplib
import json
import traceback

janus = JanusClient()
controller = ChainController()

def main(request):
	return render(request, "main/chaining.html")

def addChain(request):
    if request.method != 'POST':
        return HttpResponse("Bad Request Type")
    else:
        print request.body
        chain = json.loads(request.body)
        try:
            exChain = Chains.objects.get(name=chain['name'])
        except Chains.DoesNotExist:
            exChain = None
        if exChain != None:
            return HttpResponse("duplicate")
        else:
            head = VMs(name = chain['head']['name'], 
                       ip = chain['head']['ip'])
            head.save()
            tail = VMs(name = chain['tail']['name'], 
                       ip = chain['tail']['ip'])
            tail.save()
            middlebox = VMs(name = chain['middlebox']['name'], 
                       ip = chain['middlebox']['ip'])
            middlebox.save()
            controller.setInits('CH-'+chain['name'])
            ip1 = "192.168."+chain['head']['ip'].split(".")[2]+"."+chain['head']['ip'].split(".")[3]
            ip2 = "192.168."+chain['middlebox']['ip'].split(".")[2]+"."+chain['middlebox']['ip'].split(".")[3]
            ip3 = "192.168."+chain['tail']['ip'].split(".")[2]+"."+chain['tail']['ip'].split(".")[3]
            flows = controller.chain2(ip1, ip3, ip2)
            newChain = Chains(name = chain['name'], 
                              head = head,
                              middlebox = middlebox,
                              tail = tail)
            newChain.save()
            for flow in flows:
                entry = FlowEntry(label = flow['user_id'],
                                  chain = newChain,
                                  dpid = flow['dpid'],
                                  flow = json.dumps(flow))
                entry.save()
            return HttpResponse("success")

def removeChain(request):
    if request.method == 'POST':
        return HttpResponse("Bad Request Type")
    else:
        chainName = request.GET.get('name', '')
        try:
            exChain = Chains.objects.get(name=chainName)
        except Chains.DoesNotExist:
            exChain = None
        if exChain == None:
            return HttpResponse("Not Found")
        else:
            flows = FlowEntry.objects.filter(chain = exChain)
            for flow in flows:
                janus.delFlow(flow.label.replace(" ", "%20"))
                flow.delete()
            exChain.delete()
            return HttpResponse("success")

def getChains(request):
    chains = Chains.objects.all()
    return HttpResponse(json.dumps([chain.get_json() for chain in chains]))

def getVMs(request):
    respJson = []       
    with open('/home/ubuntu/vino_orc/servers.json') as serversJson:    
    	servers = json.load(serversJson)
	for ip in servers:
		node = {}
		node["ip"] = ip
		node["name"] = servers[ip]["name"]
		respJson.append(node)
    ret = json.dumps(respJson)
    return HttpResponse(ret)
