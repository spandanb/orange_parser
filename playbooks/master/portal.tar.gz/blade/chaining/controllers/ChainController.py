import sys
import httplib
import json
import time
import traceback

class ChainController(object):
    
    
    def __init__(self):
	self.port = 8091
        self.host = "127.0.0.1"
        
    def setInits(self, label):
        #self.port = self.regionTunnelPorts[region]
        self.flow_name = label
    
    def _forward2Controller(self, host, port, method, url, body = None):
        print "%s, %s, %s, %s" %(host, port, method, url)
    
        res = None
        try:
            _conn=httplib.HTTPConnection(host,port)
            if body:
                header = {"Content-Type": "application/json"}
                _conn.request(method, url, body=body, headers=header)
            else:
                _conn.request(method, url)
            res = _conn.getresponse()
            ret = res.read()
        except:
            traceback.print_exc()
            pass
        if res.status in (httplib.OK,
                          httplib.CREATED,
                          httplib.ACCEPTED,
                          httplib.NO_CONTENT):
            return ret
    
        raise httplib.HTTPException(
            res, 'code %d reason %s' % (res.status, res.reason),
            res.getheaders(), res.read())
    
    
    def chain(self, in_ip, ip_a, ip_b):
        flows = []
        ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_a))
        print ret
        resp = json.loads(ret)
        if resp.get('complete', False) is False:
            if resp.get('request_submitted', False) is False:
                return
        time.sleep(2)
        ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_b))
        print ret
        resp = json.loads(ret)
        if resp.get('complete', False) is False:
            if resp.get('request_submitted', False) is False:
                return
        time.sleep(2)
        ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(ip_b, ip_a))
        print ret
        resp = json.loads(ret)
        if resp.get('complete', False) is False:
            if resp.get('request_submitted', False) is False:
                return
        time.sleep(2)
        ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_b))
        resp1 = json.loads(ret)
        ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(ip_a, ip_b))
        resp2 = json.loads(ret)
        ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(ip_b, in_ip))
        resp1_reverse = json.loads(ret)
        ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(ip_b, ip_a))
        resp2_reverse = json.loads(ret)
    
        mac_a = resp2['src_mac']
        mac_b = resp2['dst_mac']
        mac_in = resp1['src_mac']
    
        path = resp1['path']
    
        for p in path:
            (dpid, in_port, out_port) = p
            print "%s, %s, %s" %(dpid, in_port, out_port)
            flow1 = {}
            flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
            flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'tp_dst':80, 'dl_src': mac_in, 'dl_dst': mac_a,
           #flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 1, 'dl_src': mac_in, 'dl_dst': mac_a,
                                                      'in_port': in_port}})
            flow1['actions'] = []
            flow1['actions'].append({'type': 'SET_DL_DST', 'dl_dst': mac_b})
            flow1['actions'].append({'type': 'OUTPUT', 'port': out_port})
            print flow1
            ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
            flows.append(flow1)
            print (dpid, ret)
            break
    
        path = resp2['path']
    
        for p in path:
            (dpid, in_port, out_port) = p
            print "%s, %s, %s" %(dpid, in_port, out_port)
            flow1 = {}
            flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
            flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'dl_src': mac_a, 'dl_dst': mac_in, 'tp_src':80,
            #flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 1, 'dl_src': mac_a, 'dl_dst': mac_in,
                                                       'in_port': in_port}})
            flow1['actions'] = []
            flow1['actions'].append({'type': 'SET_DL_DST', 'dl_dst': mac_b})
            flow1['actions'].append({'type': 'OUTPUT', 'port': out_port})
            print flow1
            ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
            flows.append(flow1)
            print (dpid, ret)
            break
    
        path = resp2_reverse['path']
        for p in path:
            (dpid, in_port, out_port) = p
            print "%s, %s, %s" %(dpid, in_port, out_port)
            flow1 = {}
            flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
            flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'dl_src': mac_b, 'dl_dst':'ALL', 'tp_dst':80, 'nw_dst': '%s/32' % ip_a,
            #flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 1, 'dl_src': mac_b, 'dl_dst':'ALL', 'nw_dst': '%s/32' % ip_a,
                                                       'in_port': in_port}})
            flow1['actions'] = []
            flow1['actions'].append({'type': 'SET_DL_DST', 'dl_dst': mac_a})
            flow1['actions'].append({'type': 'OUTPUT', 'port': out_port})
            print flow1
            ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
            print (dpid, ret)
            flows.append(flow1)
            break
    
        path = resp1_reverse['path']
        for p in path:
            (dpid, in_port, out_port) = p
            print "%s, %s, %s" %(dpid, in_port, out_port)
            flow1 = {}
            flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
            flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'dl_src': mac_b, 'tp_src':80, 'dl_dst':'ALL', 'nw_src': '%s/32' % ip_a,
            #flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 1, 'dl_src': mac_b, 'dl_dst':'ALL', 'nw_src': '%s/32' % ip_a,
                                                       'in_port': in_port}})
            flow1['actions'] = []
            flow1['actions'].append({'type': 'SET_DL_DST', 'dl_dst': mac_in})
            flow1['actions'].append({'type': 'OUTPUT', 'port': out_port})
            print flow1
            ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
            print (dpid, ret)
            flows.append(flow1)
            break
        return flows

    def chain2(self, in_ip, ip_a, ip_b):
	print in_ip
	print ip_a
	print ip_b
    	ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_a))
    	print ret
    	resp = json.loads(ret)
    	if resp.get('complete', False) is False:
    	   if resp.get('request_submitted', False) is False:
    	      return
    	time.sleep(2)
    	ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_b))
    	print ret
    	resp = json.loads(ret)
    	if resp.get('complete', False) is False:
    	   if resp.get('request_submitted', False) is False:
    	      return
    	time.sleep(2)
    	ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/path/%s_%s' %(ip_b, ip_a))
    	print ret
    	resp = json.loads(ret)
    	if resp.get('complete', False) is False:
    	   if resp.get('request_submitted', False) is False:
    	      return
    	time.sleep(2)
    	ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(in_ip, ip_b))
    	resp1 = json.loads(ret)
    	ret = self._forward2Controller(self.host, self.port, 'GET', '/v1.0/network/networks/path/%s_%s' %(ip_a, ip_b))
    	resp2 = json.loads(ret)

    	mac_a = resp2['src_mac']
    	mac_b = resp2['dst_mac']
    	mac_in = resp1['src_mac']

    	path = resp1['path']
	flows = []
    	l = len(path)
    	i = 0
    	for p in path:
    	   i = i + 1
    	   (dpid, in_port, out_port) = p
    	   if i == l:
    	       out_port = 2
    	   print "%s, %s, %s" %(dpid, in_port, out_port)
    	   flow1 = {}
    	   flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
    	   flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'dl_src': mac_in, 'dl_dst': mac_a,
    	                                              'in_port': in_port}})
    	   print flow1
    	   ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
    	   print (dpid, ret)
	   flows.append(flow1)
    	path = resp2['path']

    	l = len(path)
    	i = 0
    	for p in path:
    	   i = i + 1
    	   (dpid, in_port, out_port) = p
           if i == l:
               out_port = 3
           print "%s, %s, %s" %(dpid, in_port, out_port)
           flow1 = {}
           flow1 = {'user_id': self.flow_name, 'hard_timeout': 0, 'actions': [{'type': 'OUTPUT', 'port': out_port}], 'priority': 60000, 'idle_timeout': 0, 'cookie': 0}
           flow1.update({'dpid': int(dpid, 16), 'match': {'dl_type': 2048, 'nw_proto': 6, 'dl_src': mac_a, 'dl_dst': mac_in,
                                                      'in_port': in_port}})
           print flow1
           ret = self._forward2Controller(self.host, self.port, 'POST', '/v1.0/network/networks/user_flow_add/%s' % flow1.get('dpid'), json.dumps(flow1))
           print (dpid, ret)
    	   flows.append(flow1)
	return flows
