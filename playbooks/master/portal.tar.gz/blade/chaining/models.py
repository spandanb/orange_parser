from __future__ import unicode_literals

from django.db import models

# Create your models here.
class server(models.Model):
    id= models.CharField(max_length=50)
    name= models.CharField(max_length=50)
    ip= models.CharField(max_length=50, primary_key=True)
    def get_json(self):
        return {'id':self.id,
                'name': self.name,
                'ip': self.ip}
    pass

class chain(models.Model):
    name= models.CharField(max_length=50, primary_key=True)
    head= models.ForeignKey(server, on_delete=models.CASCADE, related_name='chain_head')
    tail= models.ForeignKey(server, on_delete=models.CASCADE, related_name='chain_tail')
    middlebox= models.ForeignKey(server, on_delete=models.CASCADE, related_name='chian_middlebox')
    def get_json(self):
        return {'name': self.name,
                'head': self.head.get_json(),
                'tail': self.tail.get_json(),
                'middlebox': self.middlebox.get_json()}
    pass

class FlowEntry(models.Model):
    label= models.CharField(max_length=50)
    chain = models.ForeignKey(chain, on_delete=models.CASCADE)
    dpid= models.BigIntegerField()
    flow= models.TextField()
    def get_json(self):
        return {'label': self.label,
                'dpid': self.dpid,
                'flow': self.flow,
                'chain': self.chian.get_json()}
    pass
