'''
Created on Feb 29, 2016

@author: Saeed Arezoumand
'''

import subprocess
import paramiko
import xmltodict
import json

class GeniClient(object):
    
    omniPath= ""
    
    def setOmniPath(self, path):
        self.omniPath = path

    def _subprocess_cmd(self, command):
        process = subprocess.Popen(command,stdout=subprocess.PIPE, shell=True)
        proc_stdout = process.communicate()[0].strip()
        return proc_stdout

    def omniConfig(self):
        commands = ''
        commands += "cd "+self.omniPath+";"
        commands += "mkdir .gcf;"
        commands += "/usr/local/bin/gcf-2.10/src/omni-configure.py -z omni.bundle -c .gcf/omni-config -p .ssl/geni_cert_portal.pem -k .ssl/geni_ssl_portal.key -s .ssh/"
        self._subprocess_cmd(commands)

    def getSliceList(self, project):
        commands = ''
        commands += "cd "+self.omniPath+";"
        commands += "/usr/local/bin/gcf-2.10/src/omni.py -c .gcf/omni-config --project="+project+" listslices -o"
        self._subprocess_cmd(commands)

    def getProjectList(self):
        commands = ''
        commands += "cd "+self.omniPath+";"
        commands += "/usr/local/bin/gcf-2.10/src/omni.py -c .gcf/omni-config listprojects -o"
        self._subprocess_cmd(commands)
        
    def getResources(self, project, slice, region):
        commands = ''
        commands += "cd "+self.omniPath+";"
        commands += "/usr/local/bin/gcf-2.10/src/omni.py -c .gcf/omni-config --project="+project+" listresources "+slice+" --useSliceAggregates -o -p "+region+" -a "+region
        self._subprocess_cmd(commands)
        out_file_path = self._subprocess_cmd("find -name "+region+"-*").split("/")[1]
        out_file = open(out_file_path, "r")
        out_xml = out_file.read()
        out_dict = xmltodict.parse(out_xml)
        return out_dict
        
        
    def getAdapterInfo(self, host, user, passphrase):
        key = paramiko.RSAKey.from_private_key_file(self.omniPath+ "/.ssh/geni_key_portal", passphrase)
        cmd = paramiko.SSHClient()
        cmd.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        cmd.connect(hostname = host, username = user, pkey = key)
        adapters = []
        stdout= cmd.exec_command("ifconfig")
        output = stdout[1].read()
        out_list = output.split("\n\n")
        for item in out_list:
            if not item.startswith("lo") and len(item.strip(' \t\n\r'))>0:
                adapter = {}
                adapter["name"] = item.split()[0]
                adapter["mac"] = self._get_value(item, "HWaddr")
                adapter["ip"] = self._get_value(item, "inet addr:")
                adapter["ipV6"] = self._get_value(item, "inet6 addr:")
                adapters.append(adapter)
        cmd.close()
        print adapters
        return adapters
        
    def _get_value(self, string, key):
        return string.split(key)[1].split()[0].strip(' \t\n\r')