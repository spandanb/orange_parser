var savi, chainlist= new Array(), vmlist= new Array(), cchain, newChain={}, cserver, nameselected = false, headselected=false, middleselected=false, tailselected=false, cbotton;

$(document).ready(function(){
	pageInit();
	
	$.ajaxSetup({ 
		 beforeSend: function(xhr, settings) {
			 function getCookie(name) {
				 var cookieValue = null;
				 if (document.cookie && document.cookie != '') {
					 var cookies = document.cookie.split(';');
					 for (var i = 0; i < cookies.length; i++) {
						 var cookie = jQuery.trim(cookies[i]);
						 // Does this cookie string begin with the name we want?
						 if (cookie.substring(0, name.length + 1) == (name + '=')) {
							 cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
							 break;
						 }
					 }
				 }
				 return cookieValue;
			 }
			 if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
				 // Only send the token to relative URLs i.e. locally.
				 xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
			 }
		 } 
	});
	
	$("#servers").on("click", "button.add-node", function(){
		if (!($(this).hasClass("disabled"))){
			console.log($(this).hasClass("disabled"))
			var ip = $(this).attr("id");
			for (j=0; j < vmlist.length; j++){
				if (vmlist[j].ip==ip){
					cserver = vmlist[j];
					console.log(cserver.ip);
					break;
				}
			}
			cbotton = $(this);
			$("#add-node-modal").modal("toggle");
		}
	});

	$("#head").on("click", "button.remove-head", function(){
		$("#head").empty();
		$("#add-head").removeClass("disabled");
	});

	$("#middle").on("click", "button.remove-middle", function(){
		$("#middle").empty();
		$("#add-middle").removeClass("disabled");
	});
	
	$("#tail").on("click", "button.remove-tail", function(){
		$("#tail").empty();
		$("#add-tail").removeClass("disabled");
	});
	
	
	$("#chains").on("click", "li.chain-item", function(){
		var chainName = $(this).text();
		if (chainName != cchain){
			cchain = chainName;
			showChains(cchain);
			showVMs(false);
		}
	});
	
	$("#add-chain").click(function(){
		newName = $("#add-chain-name").val();
		$("#chains-title").text(newName);
		newChain.name = newName;
		$("#head").empty();
		$("#middle").empty();
		$("#tail").empty();
		showVMs(true);
		nameselected = true;
	});
	
	$("#add-head").click(function(){
		console.log("add head");
		newChain.head = cserver;
		node = cserver;
		$("#head").empty();
		$("#head").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td><button type=\"button\" class=\"btn btn-sm btn-danger remove-head\" id = \""+node.mac+"\">Remove</button></td></tr>");
		headselected= true;
		$("#add-head").addClass("disabled");
		cbotton.addClass("disabled");
		if (nameselected && headselected && middleselected && tailselected){
			$("#setup-chain").removeClass("disabled");
			$("#remove-chain").addClass("disabled");
		}
	});
	
	$("#add-middle").click(function(){
		newChain.middlebox = cserver;
		node = cserver;
		$("#middle").empty();
		$("#middle").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td><button type=\"button\" class=\"btn btn-sm btn-danger remove-middle\">Remove</button></td></tr>");
		middleselected= true;
		$("#add-middle").addClass("disabled");
		cbotton.addClass("disabled");
		if (nameselected && headselected && middleselected && tailselected){
			$("#setup-chain").removeClass("disabled");
			$("#remove-chain").addClass("disabled");
		}
	});
	
	$("#add-tail").click(function(){
		newChain.tail = cserver;
		node = cserver;
		$("#tail").empty();
		$("#tail").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td><button type=\"button\" class=\"btn btn-sm btn-danger remove-tail\">Remove</button></td></tr>");
		tailselected= true;
		$("#add-tail").addClass("disabled");
		cbotton.addClass("disabled");
		if (nameselected && headselected && middleselected && tailselected){
			$("#setup-chain").removeClass("disabled");
			$("#remove-chain").addClass("disabled");
		}
	});
	
	$("#setup-chain").click(function(){
		showLoading("Wiring Up");
		$.post("/chaining/addchain/", JSON.stringify(newChain), function(result){
			if(result=="success"){
				showChains(newChain.name);
				showSuccess("Success");
			}
		});
	});
	
	$("#remove-chain").click(function(){
		bootbox.confirm('Are you sure you want to remove chain: '+cchain+'?', function(result) {
			if(result){
				showLoading("Removing Chain");
				$.get("/chaining/removechain?name="+cchain, function(data, status){
					if (data == "success"){
						showChains(null);
						showVMs(false);
					}
				});
			}
		});
	});
	
	
});

function showChains(ichain){
	showLoading("Loading Chains");
	$.getJSON("/chaining/getchains", function(resp){
		$("#chains").empty();
		$("#chains-title").text("Chains");
	    	chainlist = resp;
		for (i=0; i< chainlist.length; i++){
			var chain = chainlist[i];
			if (ichain == null){
				if(i==0){
					chain = chainlist[i];
					$("#chains-title").text(chain.name);
					cchain = chain.name;
					var node = chain.head;
					$("#head").empty();
					$("#head").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					node = chain.middlebox;
					$("#middle").empty();
					$("#middle").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					node = chain.tail;
					$("#tail").empty();
					$("#tail").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					$("#setup-chain").addClass("disabled");
					$("#remove-chain").removeClass("disabled");
				}
			}
			else{
				if (chain.name == ichain){
					$("#chains-title").text(ichain);
					cchain = ichain;
					var node = chain.head;
					$("#head").empty();
					$("#head").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					node = chain.middlebox;
					$("#middle").empty();
					$("#middle").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					node = chain.tail;
					$("#tail").empty();
					$("#tail").append("<tr id=\""+node.name+"\"><td>"+node.name+"</td><td>"+node.ip+"</td><td></td></tr>");
					$("#setup-chain").addClass("disabled");
					$("#remove-chain").removeClass("disabled");
				}
			}			
			$("#chains").append("<li class=\"chain-item\"><a href=\"#\">"+chain.name+"</a></li>");
		}
	});
}

function showVMs(enable){
	showLoading("Loading VMs");
	$("#servers").empty();
	$.getJSON("/chaining/getvms", function(resp){
	    vmlist = resp;
		for (j=0; j < vmlist.length; j++){
			var server = vmlist[j];
			if(!enable)
				$("#servers").append("<tr id=\""+server.name+"\"><td>"+server.name+"</td><td>"+server.ip+"</td><td><button type=\"button\" class=\"btn btn-sm btn-primary disabled add-node\" id = \""+server.ip+"\">Add</button></td></tr>");
			else 
				$("#servers").append("<tr id=\""+server.name+"\"><td>"+server.name+"</td><td>"+server.ip+"</td><td><button type=\"button\" class=\"btn btn-sm btn-primary add-node\" id = \""+server.ip+"\">Add</button></td></tr>");
		}
		showSuccess("Success");
	});
	
}

function pageInit(){
		showChains(null);
		console.log("wans done");
		showVMs(false);
}

function showLoading(mes){
		$("#loading").css({"display":"block", "background-color":"#E1F5FE", "border-color":"#01579B"});
		$("div.cssload-container").css({"display":"block"});
		$("#loading-holder").css({"display":"none"});
		$("#l-message").text(mes);
		$("#l-message").attr("class", "text-primary");
}

function showSuccess(mes){
		$("#loading").css({"display":"block"});
		$("div.cssload-container").css({"display":"none"});
		$("#loading-holder").css({"display":"block"});
		$("#l-message").text(mes);
		$("#l-message").attr("class", "text-success");
		$("#loading").delay(1000).fadeOut(2000);
}

function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
